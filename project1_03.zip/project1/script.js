'use strict'

document.getElementById('form1').addEventListener('submit', function(event) { event.preventDefault();
let budget=document.getElementById('budget').value ;
let cost =document.getElementById('cost').value;
let existential=document.getElementById('existential');
// let budget = parseFloat(document.getElementById('budget').value);
// let cost = parseFloat(document.getElementById('cost').value);


// budget=cost;

if(budget){
    if(budget>0){
    budget+=budget;}
    // document.getElementById("num1").innerHTML = budget
    document.getElementById("num1").innerText = `$${budget}`;
}

else  {
    document.getElementById("num1").innerText = '$0';
}

});








